-- iOS Unity premake module
local platform = {}

function platform.setupTargetAndLibDir(baseTargetDir)
    targetdir(baseTargetDir .. "iOS/%{cfg.buildcfg}")
    libdirs("${WWISESDK}/iOS_Xcode1500/$(CONFIGURATION)$(EFFECTIVE_PLATFORM_NAME)/lib/")
end

function platform.platformSpecificConfiguration()
    kind "StaticLib"
    xcodebuildsettings {
        OTHER_LIBTOOLFLAGS = "$(OTHER_LDFLAGS)",
        SEPARATE_STRIP = "NO",
        LINK_WITH_STANDARD_LIBRARIES = "NO",
        PRODUCT_BUNDLE_IDENTIFIER = "com.audiokinetic.wwiseunityintegration"
    }
    links { 
        "Foundation.framework",
        "UIKit.framework",
        "AVFoundation.framework",
        "AudioToolbox.framework",
        "CoreAudio.framework"
    }
end

return platform